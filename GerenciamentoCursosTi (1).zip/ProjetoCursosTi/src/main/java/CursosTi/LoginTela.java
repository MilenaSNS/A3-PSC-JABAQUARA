package CursosTi;

import javax.swing.JOptionPane;


public class LoginTela extends javax.swing.JFrame {

   // Construtor da classe LoginTela
    public LoginTela() {
        super("Tela de login");// Define o título da janela
        initComponents();// Inicializa os componentes da interface gráfica
        setLocationRelativeTo(null);// Centraliza a janela na tela
        this.pack();// Ajusta o tamanho da janela de acordo com os componentes
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtUsuario = new javax.swing.JTextField();
        txtPassword = new javax.swing.JPasswordField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtPalavraSecreta = new javax.swing.JTextField();
        btnEntar = new javax.swing.JButton();
        btnSair = new javax.swing.JButton();
        btnEnviar = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(554, 554));
        getContentPane().setLayout(null);

        txtUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUsuarioActionPerformed(evt);
            }
        });
        getContentPane().add(txtUsuario);
        txtUsuario.setBounds(105, 111, 243, 42);

        txtPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPasswordActionPerformed(evt);
            }
        });
        getContentPane().add(txtPassword);
        txtPassword.setBounds(105, 175, 243, 41);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Portal Edu TI");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(180, 40, 201, 32);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Usuario:");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(38, 121, 55, 20);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Senha:");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(38, 184, 44, 20);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Esqueceu a senha?");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(6, 318, 101, 16);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Palavra secreta:");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(6, 365, 87, 16);
        getContentPane().add(txtPalavraSecreta);
        txtPalavraSecreta.setBounds(105, 352, 188, 42);

        btnEntar.setBackground(new java.awt.Color(0, 51, 102));
        btnEntar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnEntar.setText("Entrar");
        btnEntar.setBorder(null);
        btnEntar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEntarActionPerformed(evt);
            }
        });
        getContentPane().add(btnEntar);
        btnEntar.setBounds(350, 250, 90, 50);

        btnSair.setBackground(new java.awt.Color(0, 51, 102));
        btnSair.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnSair.setText("Sair");
        btnSair.setBorder(null);
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });
        getContentPane().add(btnSair);
        btnSair.setBounds(105, 250, 90, 50);

        btnEnviar.setBackground(new java.awt.Color(0, 51, 102));
        btnEnviar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnEnviar.setText("Enviar");
        btnEnviar.setBorder(null);
        btnEnviar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnviarActionPerformed(evt);
            }
        });
        getContentPane().add(btnEnviar);
        btnEnviar.setBounds(320, 360, 82, 30);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img login.jpeg"))); // NOI18N
        getContentPane().add(jLabel6);
        jLabel6.setBounds(0, 0, 560, 550);
        getContentPane().add(jLabel7);
        jLabel7.setBounds(0, 0, 87, 62);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEntarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEntarActionPerformed
        String login = txtUsuario.getText();// Obtém o texto do campo de usuário
        String senha = new String(txtPassword.getPassword());// Obtém o texto do campo de senha
        
         try{
            Usuario usuario = new Usuario(login, senha);
            DAO dao = new DAO();// Cria uma instância do DAO
            if(dao.existe(usuario)){// Verifica se o usuário existe no banco de dados
                JOptionPane.showMessageDialog(null, "Bem vindo, " + usuario.getLogin() + "!");
                Menu m = new Menu();// Cria uma instância da tela de Menu
                m.setVisible(true);// Torna a tela de Menu visível
                this.dispose();// Fecha a tela de login
                
          }else{
                JOptionPane.showMessageDialog(null, "Usuário ou senha incorretas!");
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Problemas técnicos. Tente novamente mais tarde.");
        }
    }//GEN-LAST:event_btnEntarActionPerformed

    private void txtPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPasswordActionPerformed
        
    }//GEN-LAST:event_txtPasswordActionPerformed

    private void txtUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUsuarioActionPerformed
         String login = txtUsuario.getText();
         String senha = new String(txtPassword.getPassword());
        
        //Verficar usuario válido
       if(login.equals("admin") && senha.equals("admin")){
           JOptionPane.showMessageDialog(null, "Bem-Vindo!");
           
       }else{
           JOptionPane.showMessageDialog(null, "Usuário ou senha incorretas!");
       }
    }//GEN-LAST:event_txtUsuarioActionPerformed

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnSairActionPerformed

    private void btnEnviarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnviarActionPerformed
         String secreta = txtPalavraSecreta.getText();
         
         if(secreta.equals ("admin@123")){
             JOptionPane.showMessageDialog(null, "O seu usuário e senha é: 'admin'");
         }
         
    }//GEN-LAST:event_btnEnviarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoginTela.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoginTela.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoginTela.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginTela.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginTela().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEntar;
    private javax.swing.JButton btnEnviar;
    private javax.swing.JButton btnSair;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JTextField txtPalavraSecreta;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
