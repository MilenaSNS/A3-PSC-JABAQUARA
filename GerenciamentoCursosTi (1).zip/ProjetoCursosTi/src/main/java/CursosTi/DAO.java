package CursosTi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class DAO {
    // Método para verificar se um usuário existe no banco de dados
       public boolean existe(Usuario usuario)throws Exception{
        String sql = "SELECT * FROM usuarios WHERE login = ? AND senha = ?";
        
        // Tenta estabelecer uma conexão e executar a consulta
        try(Connection conn = Conexao.obtemConexao()){
        PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, usuario.getLogin());
            ps.setString(2, usuario.getSenha());
            
            try(ResultSet rs = ps.executeQuery()){ // Executa a consulta e verifica se há algum resultado
                return rs.next();// Retorna true se existir um registro
            }      
        }
    }
       // Método para cadastrar um novo estudante no banco de dados
       public void CadastarEstudante(Estudante estudante)throws Exception{ 
            String sql = "INSERT INTO estudantes (nome, fone, email, n_cad, cursos_id) "
                    + "values(?, ?, ?, ?, ?)";
    
       // Tenta estabelecer uma conexão e executar a inserção
        try(Connection conn = Conexao.obtemConexao()){
        PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, estudante.getNome());
            ps.setString(2, estudante.getFone());
            ps.setString(3, estudante.getEmail());
            ps.setInt(4, estudante.getN_cad());
            ps.setInt(5, estudante.getCursos_id()); 
          ps.execute();
    }
      }
       
       // Método para editar as informações de um estudante existente
       public void EditarEstudante(Estudante estudante)throws Exception{
           String sql = "UPDATE estudantes SET nome = ?, fone = ?, email = ?, n_cad = ?,"
                   + " cursos_id = ? WHERE id = ? ";
           
       // Tenta estabelecer uma conexão e executar a atualização
         try(Connection conn = Conexao.obtemConexao()){
         PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, estudante.getNome());
            ps.setString(2, estudante.getFone());
            ps.setString(3, estudante.getEmail());
            ps.setInt(4, estudante.getN_cad());
            ps.setInt(5, estudante.getCursos_id()); 
            ps.setInt(6, estudante.getId());
             ps.execute();
       }
           }
       
       // Método para deletar um estudante do banco de dados
       public void DeletarEstudante(Estudante estudante)throws Exception{
           String sql = "DELETE FROM estudantes WHERE id = ?";
           
       // Tenta estabelecer uma conexão e executar a exclusão
           try(Connection conn = Conexao.obtemConexao()){
              PreparedStatement ps = conn.prepareStatement(sql);
              ps.setInt(1, estudante.getId());
              ps.execute();
           }
         }
       
       // Método para inserir um novo curso no banco de dados
        public void inserir(Cursos cursos)throws Exception{ 
            String sql = "INSERT INTO cursos (nome, nivel) values(?, ?)";
    
      // Tenta estabelecer uma conexão e executar a inserção
    try(Connection conn = Conexao.obtemConexao()){
        PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, cursos.getNome());
            ps.setString(2, cursos.getNivel());
          ps.execute();
    }
      }
        
      // Método para atualizar as informações de um curso existente
        public void atualizar(Cursos cursos)throws Exception{
           String sql = "UPDATE cursos SET nome = ?, nivel = ? WHERE id = ? ";
           
       // Tenta estabelecer uma conexão e executar a atualização
           try(Connection conn = Conexao.obtemConexao()){
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, cursos.getNome());
            ps.setString(2, cursos.getNivel());
            ps.setInt(3, cursos.getId());
            ps.execute();
       }
      }
        
        // Método para deletar um curso do banco de dados
        public void DeletarCursos(Cursos curso)throws Exception{
           String sql = "DELETE FROM cursos WHERE id = ?";
           
        // Tenta estabelecer uma conexão e executar a exclusão
           try(Connection conn = Conexao.obtemConexao()){
              PreparedStatement ps = conn.prepareStatement(sql);
              ps.setInt(1, curso.getId());
              ps.execute();
           }
         }
}
  