package CursosTi;


public class Usuario {
    // Atributos privados para armazenar login e senha
    private String login;
    private String senha;
    
    //Construtor da classe Usario
    public Usuario(String login, String senha){
        this.login = login;// Inicializa o atributo login com o valor passado como parâmetro
        this.senha = senha;// Inicializa o atributo senha com o valor passado como parâmetro
    }
    // Método getter para obter o valor do login
    public String getLogin() {
        return login;
    }
    // Método setter para definir o valor do login
    public void setLogin(String login) {
        this.login = login;
    }
    // Método getter para obter o valor da senha
    public String getSenha() {
        return senha;
    }
    // Método setter para definir o valor da senha
    public void setSenha(String senha) {
        this.senha = senha;
    }
   
}

