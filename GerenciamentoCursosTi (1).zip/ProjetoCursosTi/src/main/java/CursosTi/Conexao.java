package CursosTi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Conexao {
    // Variáveis para armazenar os detalhes da conexão com o banco de dados
    private static String host = "localhost";
    private static String porta = "3306";
    private static String db = "sistemaCursosTi";
    private static String usuario = "root";
    private static String senha = "Milena";    
    
    // Método que obtém uma conexão com o banco de dados
    public static Connection obtemConexao(){
        try{
            // Tenta estabelecer uma conexão com o banco de dados
            Connection c = DriverManager.getConnection("jdbc:mysql://" + host + ":" 
                    + porta + "/" + db + "?useTimezone=true&serverTimezone=UTC", usuario, senha);
            
            return c;// Retorna a conexão estabelecida
        }
        catch(SQLException e){
            return null;// Em caso de exceção, retorna null
    }
  }
}

