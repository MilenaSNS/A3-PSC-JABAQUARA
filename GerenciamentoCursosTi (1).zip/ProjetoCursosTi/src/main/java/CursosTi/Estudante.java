
package CursosTi;


public class Estudante {
    private int id;
    private String nome;
    private String fone;
    private String email;
    private int n_cad;
    private int cursos_id;

    public Estudante(int id, String nome, String fone, String email, int n_cad, int cursos_id) {
        this.id = id;
        this.nome = nome;
        this.fone = fone;
        this.email = email;
        this.n_cad = n_cad;
        this.cursos_id = cursos_id;
    }
    public int getId(){
     return id;   
    }
    public void setId(int id){
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }

    public String getEmail() {
        return email;
    }

   public void setEmail(String email) {
    this.email = email;
}

    public int getN_cad() {
        return n_cad;
    }

    public void setN_cad(int n_cad) {
        this.n_cad = n_cad;
    }

    public int getCursos_id() {
        return cursos_id;
    }

    public void setCursos_id(int cursos_id) {
        this.cursos_id = cursos_id;
    }
}
    

